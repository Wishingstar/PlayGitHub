/*

This is a prototype Javascript API for Sketch.

The intention is to make something which is:

- native Javascript
- an easily understandable subset of the full internals of Sketch
- fully supported by Bohemian between releases (ie we try not to change it, unlike our internal API which we can and do change whenever we need to)
- still allows you to drop down to our internal API when absolutely necessary.

Comments and suggestions for this API are welcome - send them to developer@sketchapp.com.

All code (C) 2016 Bohemian Coding.


** PLEASE NOTE: this API is not final, and should be used for testing & feedback purposes only. **
** The idea eventually is that it's fixed - but until we've got the design right, it WILL change. **



Example script:

var sketch = context.api(context);

log(sketch.version());

var app = sketch.application();
log(app.version());
log(app.build());
log(app.full_version());


var document = sketch.context_document();
var selection = document.selection();
var pages = document.pages();
var page = pages[0];

var group = page.add_group("Test", CGRectMake(0, 0, 100, 100));
var rect = group.add_rectangle("Rect", CGRectMake(10, 10, 80, 80));

log(selection.is_empty());
selection.iterate(function(item) { log(item.name); } );

selection.clear();
log(selection.is_empty());

group.select();
rect.add_to_selection();

app.input("Test", "default");
app.select("Test", ["One", "Two"], 1);
app.message("Hello mum!");
app.alert("Title", "message");



*/

var __globals = this;
(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Artboard = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Layer2 = require('./Layer.js');

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

// ********************************
// Artboard support.
// ********************************

var Artboard = exports.Artboard = function (_Layer) {
  _inherits(Artboard, _Layer);

  function Artboard(artboard, document) {
    _classCallCheck(this, Artboard);

    return _possibleConstructorReturn(this, Object.getPrototypeOf(Artboard).call(this, artboard, document));
  }

  _createClass(Artboard, [{
    key: 'isArtboard',
    get: function get() {
      return true;
    }
  }]);

  return Artboard;
}(_Layer2.Layer);

},{"./Layer.js":12}],2:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Group = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Layer2 = require('./Layer.js');

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

// ********************************
// Group support.
// ********************************

var Group = exports.Group = function (_Layer) {
  _inherits(Group, _Layer);

  function Group(group, document) {
    _classCallCheck(this, Group);

    return _possibleConstructorReturn(this, Object.getPrototypeOf(Group).call(this, group, document));
  }

  _createClass(Group, [{
    key: 'is_group',
    value: function is_group() {
      return true;
    }
  }]);

  return Group;
}(_Layer2.Layer);

},{"./Layer.js":12}],3:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Image = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Layer2 = require('./Layer.js');

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

// ********************************
// Image support.
// ********************************

var Image = exports.Image = function (_Layer) {
  _inherits(Image, _Layer);

  function Image(page, document) {
    _classCallCheck(this, Image);

    return _possibleConstructorReturn(this, Object.getPrototypeOf(Image).call(this, page, document));
  }

  _createClass(Image, [{
    key: 'setImageFromURL',
    value: function setImageFromURL(url) {
      var image = NSImage.alloc().initWithContentsOfURL_(url);
      var imageData = MSImageData.alloc().initWithImage_convertColorSpace_(image, true);
      this.object.setImage_(imageData);
    }
  }, {
    key: 'isImage',
    get: function get() {
      return true;
    }
  }]);

  return Image;
}(_Layer2.Layer);

},{"./Layer.js":12}],4:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Page = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Layer2 = require('./Layer.js');

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

// ********************************
// Page support.
// ********************************

var Page = exports.Page = function (_Layer) {
  _inherits(Page, _Layer);

  function Page(page, document) {
    _classCallCheck(this, Page);

    var _this = _possibleConstructorReturn(this, Object.getPrototypeOf(Page).call(this, page));

    _this.document = document;
    return _this;
  }

  _createClass(Page, [{
    key: 'isPage',
    get: function get() {
      return true;
    }
  }]);

  return Page;
}(_Layer2.Layer);

},{"./Layer.js":12}],5:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Rectangle = exports.Rectangle = function () {
  function Rectangle(x, y, w, h) {
    _classCallCheck(this, Rectangle);

    this.x = x;
    this.y = y;
    this.width = w;
    this.height = h;
  }

  _createClass(Rectangle, [{
    key: "asCGRect",
    value: function asCGRect() {
      return CGRectMake(this.x, this.y, this.width, this.height);
    }
  }]);

  return Rectangle;
}();

},{}],6:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Shape = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Layer2 = require('./Layer.js');

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

// ********************************
// Shape support.
// ********************************

var Shape = exports.Shape = function (_Layer) {
  _inherits(Shape, _Layer);

  function Shape(shape, document) {
    _classCallCheck(this, Shape);

    return _possibleConstructorReturn(this, Object.getPrototypeOf(Shape).call(this, shape, document));
  }

  _createClass(Shape, [{
    key: 'isShape',
    get: function get() {
      return true;
    }
  }]);

  return Shape;
}(_Layer2.Layer);

},{"./Layer.js":12}],7:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Text = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _Layer2 = require('./Layer.js');

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

// ********************************
// Text support.
// ********************************

var Text = exports.Text = function (_Layer) {
  _inherits(Text, _Layer);

  function Text(text, document) {
    _classCallCheck(this, Text);

    return _possibleConstructorReturn(this, Object.getPrototypeOf(Text).call(this, text, document));
  }

  _createClass(Text, [{
    key: 'useSystemFontOfSize',
    value: function useSystemFontOfSize(size) {
      this.object.font = NSFont.systemFontOfSize_(size);
    }
  }, {
    key: 'isText',
    get: function get() {
      return true;
    }
  }, {
    key: 'text',
    get: function get() {
      return this.object.stringValue;
    },
    set: function set(value) {
      this.object.stringValue = value;
    }
  }, {
    key: 'font',
    set: function set(value) {
      this.object.font = value;
    }
  }, {
    key: 'alignment',
    set: function set(mode) {
      this.object.textAlignment = mode;
    }
  }, {
    key: 'fixedWidth',
    set: function set(value) {
      if (value) {
        this.object.textBehaviour = 1;
      } else {
        this.object.textBehaviour = 0;
      }
    }
  }]);

  return Text;
}(_Layer2.Layer);

},{"./Layer.js":12}],8:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

// ********************************
// Base class for all objects that
// wrap Sketch classes.
// ********************************

var WrappedObject = exports.WrappedObject = function () {
  function WrappedObject(object) {
    _classCallCheck(this, WrappedObject);

    this.object = object;
  }

  _createClass(WrappedObject, [{
    key: "id",
    get: function get() {
      return this.object.objectID();
    }
  }]);

  return WrappedObject;
}();

},{}],9:[function(require,module,exports){
'use strict';

var _Application = require('./Application.js');

function SketchAPIVersion1(context) {
  return new _Application.Application(context);
}

function SketchAPIWithCapturedContext(context) {
  return function () {
    return SketchAPIVersion1(context);
  };
}

__globals.SketchAPIWithCapturedContext = SketchAPIWithCapturedContext;

},{"./Application.js":10}],10:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Application = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _WrappedObject2 = require('./WrappedObject.js');

var _Document = require('./Document.js');

var _Rectangle = require('./Rectangle.js');

var _Group = require('./Group.js');

var _Text = require('./Text.js');

var _Image = require('./Image.js');

var _Shape = require('./Shape.js');

var _Artboard = require('./Artboard.js');

var _Page = require('./Page.js');

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

// ********************************
// Application support.
// ********************************

var Application = exports.Application = function (_WrappedObject) {
  _inherits(Application, _WrappedObject);

  function Application(context) {
    _classCallCheck(this, Application);

    var _this = _possibleConstructorReturn(this, Object.getPrototypeOf(Application).call(this, context));

    _this.metadata = MSApplicationMetadata.metadata();

    // this is a slightly clumsy way to pass related classes into Layer
    // without setting up a circular dependency between classes (eg Layer imports Artboard which imports Layer...)
    // there has to be a better way to do this...
    _this.factory = {
      "Group": _Group.Group,
      "Page": _Page.Page,
      "Artboard": _Artboard.Artboard,
      "Shape": _Shape.Shape,
      "Image": _Image.Image,
      "Text": _Text.Text
    };
    return _this;
  }

  _createClass(Application, [{
    key: 'settingForKey',
    value: function settingForKey(key) {
      return NSUserDefaults.standardUserDefaults().objectForKey_(key);
    }
  }, {
    key: 'setSettingForKey',
    value: function setSettingForKey(key, value) {
      NSUserDefaults.standardUserDefaults().setObject_forKey_(value, key);
    }
  }, {
    key: 'resourceNamed',
    value: function resourceNamed(name) {
      return this.object.plugin.urlForResourceNamed_(name);
    }
  }, {
    key: 'input',
    value: function input(msg, initial) {
      return this.object.document.askForUserInput_initialValue(msg, initial);
    }
  }, {
    key: 'log',
    value: function log(message) {
      print(message);
    }
  }, {
    key: 'newDocument',
    value: function newDocument() {
      var app = NSDocumentController.sharedDocumentController();
      app.newDocument_(this);
      return new _Document.Document(app.currentDocument(), this);
    }
  }, {
    key: 'select',
    value: function select(msg, items, selectedItemIndex) {
      selectedItemIndex = selectedItemIndex || 0;

      var accessory = NSComboBox.alloc().initWithFrame(NSMakeRect(0, 0, 200, 25));
      accessory.addItemsWithObjectValues(items);
      accessory.selectItemAtIndex(selectedItemIndex);

      var alert = NSAlert.alloc().init();
      alert.setMessageText(msg);
      alert.addButtonWithTitle('OK');
      alert.addButtonWithTitle('Cancel');
      alert.setAccessoryView(accessory);

      var responseCode = alert.runModal();
      var sel = accessory.indexOfSelectedItem();

      return [responseCode, sel];
    }
  }, {
    key: 'message',
    value: function message(msg) {
      this.object.document.showMessage(msg);
    }
  }, {
    key: 'alert',
    value: function alert(title, msg) {
      var app = NSApplication.sharedApplication();
      app.displayDialog_withTitle(title, msg);
    }
  }, {
    key: 'rectangle',
    value: function rectangle(x, y, w, h) {
      return new _Rectangle.Rectangle(x, y, w, h);
    }
  }, {
    key: 'api_version',
    get: function get() {
      return "1.1";
    }
  }, {
    key: 'context',
    get: function get() {
      return this.object;
    }
  }, {
    key: 'version',
    get: function get() {
      return this.metadata['appVersion'];
    }
  }, {
    key: 'build',
    get: function get() {
      return this.metadata['build'];
    }
  }, {
    key: 'full_version',
    get: function get() {
      return this.version + " (" + this.build + ")";
    }
  }, {
    key: 'frontDocument',
    get: function get() {
      return new _Document.Document(this.object.document, this);
    }
  }]);

  return Application;
}(_WrappedObject2.WrappedObject);

},{"./Artboard.js":1,"./Document.js":11,"./Group.js":2,"./Image.js":3,"./Page.js":4,"./Rectangle.js":5,"./Shape.js":6,"./Text.js":7,"./WrappedObject.js":8}],11:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Document = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _WrappedObject2 = require('./WrappedObject.js');

var _Layer = require('./Layer.js');

var _Page = require('./Page.js');

var _Selection = require('./Selection.js');

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

// ********************************
// Document support.
// ********************************

var Document = exports.Document = function (_WrappedObject) {
  _inherits(Document, _WrappedObject);

  function Document(document, application) {
    _classCallCheck(this, Document);

    var _this = _possibleConstructorReturn(this, Object.getPrototypeOf(Document).call(this, document));

    _this.application = application;
    return _this;
  }

  _createClass(Document, [{
    key: 'layer_with_id',
    value: function layer_with_id(layer_id) {
      return new _Layer.Layer(this.object.documentData().layerWithID_(layer_id), this);
    }
  }, {
    key: 'layer_with_name',
    value: function layer_with_name(layer_id) {
      // as it happens, layerWithID also matches names
      var layer = this.object.documentData().layerWithID_(layer_id);
      if (layer) return new _Layer.Layer(layer, this);
    }
  }, {
    key: 'selection',
    get: function get() {
      return new _Selection.Selection(this.object);
    }
  }, {
    key: 'selectedPage',
    get: function get() {
      print(this.object);
      return new _Page.Page(this.object.currentPage(), this);
    }
  }, {
    key: 'pages',
    get: function get() {
      var result = [];
      var loop = this.object.pages().objectEnumerator();
      var item;
      while (item = loop.nextObject()) {
        result.push(new _Page.Page(item, this));
      }
      return result;
    }
  }]);

  return Document;
}(_WrappedObject2.WrappedObject);

},{"./Layer.js":12,"./Page.js":4,"./Selection.js":13,"./WrappedObject.js":8}],12:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Layer = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _WrappedObject2 = require("./WrappedObject.js");

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

// ********************************
// Layer support.
// TODO: split this functionality up properly into wrappers for the main layer classes
// ********************************

var Layer = exports.Layer = function (_WrappedObject) {
  _inherits(Layer, _WrappedObject);

  function Layer(layer, document) {
    _classCallCheck(this, Layer);

    var _this = _possibleConstructorReturn(this, Object.getPrototypeOf(Layer).call(this, layer));

    _this.document = document;
    return _this;
  }

  _createClass(Layer, [{
    key: "duplicate",
    value: function duplicate() {
      return new Layer(this.object.duplicate(), this.document);
    }
  }, {
    key: "add_layer_with_name",
    value: function add_layer_with_name(newLayer, name, wrapper) {
      if (newLayer) {
        newLayer.setName_(name);
        var layer = this.object;
        layer.addLayers_(NSArray.arrayWithObject_(newLayer));
        var wrapperToMake = this.document.application.factory[wrapper];
        return new wrapperToMake(newLayer, this.document);
      }
    }
  }, {
    key: "newShape",
    value: function newShape(name, frame) {
      var newLayer = MSShapeGroup.shapeWithBezierPath_(NSBezierPath.bezierPathWithRect_(frame.asCGRect()));
      return this.add_layer_with_name(newLayer, name, "Shape");
    }
  }, {
    key: "newText",
    value: function newText(name, frame, text) {
      var newLayer = MSTextLayer.alloc().initWithFrame_(frame.asCGRect());
      newLayer.adjustFrameToFit();
      return this.add_layer_with_name(newLayer, name, "Text");
    }
  }, {
    key: "newGroup",
    value: function newGroup(name, frame) {
      var newLayer = MSLayerGroup.alloc().initWithFrame_(frame.asCGRect());
      return this.add_layer_with_name(newLayer, name, "Group");
    }
  }, {
    key: "newArtboard",
    value: function newArtboard(name, frame) {
      var newLayer = MSArtboardGroup.alloc().initWithFrame_(frame.asCGRect());
      return this.add_layer_with_name(newLayer, name, "Artboard");
    }
  }, {
    key: "newImage",
    value: function newImage(name, frame) {
      var newLayer = MSBitmapLayer.alloc().initWithFrame_(frame.asCGRect());
      return this.add_layer_with_name(newLayer, name, "Image");
    }
  }, {
    key: "remove",
    value: function remove() {
      var parent = this.object.parentGroup();
      if (parent) {
        parent.removeLayer_(layer);
      }
    }
  }, {
    key: "select",
    value: function select() {
      this.object.select_byExpandingSelection(true, false);
    }
  }, {
    key: "deselect",
    value: function deselect() {
      this.object.select_byExpandingSelection(false, true);
    }
  }, {
    key: "add_to_selection",
    value: function add_to_selection() {
      this.object.select_byExpandingSelection(true, true);
    }
  }, {
    key: "iterate",
    value: function iterate(block) {
      var loop = this.object().layers().objectEnumerator();
      while (item = loop.nextObject()) {
        block(new Layer(item, this.document));
      }
    }
  }, {
    key: "name",
    get: function get() {
      return this.object.name();
    },
    set: function set(value) {
      this.object.setName_(value);
    }
  }, {
    key: "frame",
    get: function get() {
      var f = this.object.frame();
      return new Rectangle(f.x(), f.y(), f.width(), f.height());
    },
    set: function set(value) {
      var f = this.object.frame();
      f.setRect_(NSMakeRect(value.x, value.y, value.width, value.height));
    }
  }, {
    key: "isPage",
    get: function get() {
      return false;
    }
  }, {
    key: "isArtboard",
    get: function get() {
      return false;
    }
  }, {
    key: "isGroup",
    get: function get() {
      return false;
    }
  }, {
    key: "isText",
    get: function get() {
      return false;
    }
  }, {
    key: "isShape",
    get: function get() {
      return false;
    }
  }, {
    key: "isImage",
    get: function get() {
      return false;
    }
  }]);

  return Layer;
}(_WrappedObject2.WrappedObject);

},{"./WrappedObject.js":8}],13:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Selection = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _WrappedObject2 = require('./WrappedObject.js');

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

// ********************************
// Selection support.
// ********************************

var Selection = exports.Selection = function (_WrappedObject) {
  _inherits(Selection, _WrappedObject);

  function Selection(document) {
    _classCallCheck(this, Selection);

    return _possibleConstructorReturn(this, Object.getPrototypeOf(Selection).call(this, document));
  }

  _createClass(Selection, [{
    key: 'is_empty',
    value: function is_empty() {
      return this.object.selectedLayers().count() == 0;
    }
  }, {
    key: 'iterateAndClear',
    value: function iterateAndClear(block) {
      var layers = this.object.selectedLayers();
      this.clear();
      this.iterateWithLayers(layers, block);
    }
  }, {
    key: 'iterate',
    value: function iterate(block) {
      var layers = this.object.selectedLayers();
      this.iterateWithLayers(layers, block);
    }
  }, {
    key: 'iterateWithLayers',
    value: function iterateWithLayers(layers, block) {
      var loop = layers.objectEnumerator();
      var item;
      while (item = loop.nextObject()) {
        block(new Layer(item));
      }
    }
  }, {
    key: 'clear',
    value: function clear() {
      this.object.currentPage().deselectAllLayers();
    }
  }]);

  return Selection;
}(_WrappedObject2.WrappedObject);

},{"./WrappedObject.js":8}]},{},[9]);
