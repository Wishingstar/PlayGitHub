//
//  SMKMirrorConnectionsDataSource.h
//  SketchMirrorKit
//
//  Created by Robin Speijer on 17-12-15.
//  Copyright © 2015 Awkward. All rights reserved.
//

#import <Foundation/Foundation.h>

/// The data source that is being used by SketchMirrorKit to get the needed information for streaming to the Mirror app. All methods are guaranteed to be called from the main queue.
@protocol SMKMirrorDataSource <NSObject>

/// The identifier of the current visible artboard in Sketch. This will be used for the initial connection setup with the Mirror app.
@property (readonly, nullable) NSString *currentArtboardIdentifier;

/// The content hierarchy for the Sketch file that is being sent to Sketch Mirror.
@property (readonly, nullable) NSDictionary *manifestContent;

/// Render an the image for the given artboard identifier, within the specified rect at the specified scale.
- (void)renderImageForArtboardIdentifier:(nonnull NSString *)identifier
                                  inRect:(CGRect)rect
                                   scale:(CGFloat)scale
                                 handler:(void (^ _Nonnull)(NSData * _Nullable imageData))handler;
@end
